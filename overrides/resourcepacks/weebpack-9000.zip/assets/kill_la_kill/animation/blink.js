var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw,
        headPitch, scale, modelMap) {
        var snketsuBlink = modelMap.get("snketsuBlink")
        if (snketsuBlink != undefined) {
            var remainder = (ageInTicks + Math.abs(entity.getSeed()) % 10) % 60
            snketsuBlink.setHidden(!(55 < remainder && remainder < 60))
        }
    }
})