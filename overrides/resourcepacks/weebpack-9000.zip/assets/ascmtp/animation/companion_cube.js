var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        cube = modelMap.get("cube");
        speed = Math.sin(ageInTicks % 360) * 0.25 * limbSwingAmount

        if (maid.isSitting()) {
            cube.setRotateAngleX(0)
            cube.setOffsetZ(0)
        } else if (limbSwingAmount > 0.1) {
            cube.setRotateAngleX(ageInTicks % 360 * 0.25 - (speed));
            cube.setOffsetZ(speed * limbSwingAmount)
        } else {
            cube.setRotateAngleX(0)
            cube.setOffsetZ(0)
        }
    }
})